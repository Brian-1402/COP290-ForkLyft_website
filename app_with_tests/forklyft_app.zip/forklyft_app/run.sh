# export FLASK_APP=app
# export FLASK_DEBUG=1
# flask run
flask --app forklyft --debug run